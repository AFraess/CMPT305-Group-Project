This Maven project assumes that you have installed a Java JDK version 21 or higher.

If IntelliJ can’t find the configured JDK (Temurin JDK version 25), you may have to select an installed JDK by going to
Project Structure -> Project Settings -> Project and selecting a JDK in the SDK dropdown menu.

If you receive an error that the "Module SDK version is not compatible with the source version 21", or
"Unsupported major.minor version 65.0", I recommend that you install the Temurin JDK version 25.
Instructions are available in the Resources section on mêskanâs. Alternatively, you can change the
maven.compiler.source and maven.compiler.target versions in the pom.xml file to match the JDK version you are using.
Some code may not be compatible with older versions.

IMPORTANT:
Mark the src/main/java/cmpt305/javafx_demos/arcgis directory as Excluded to avoid compilation errors.