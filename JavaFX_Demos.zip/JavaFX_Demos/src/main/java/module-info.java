module cmpt305.javafx_demos {
    requires javafx.controls;
    requires javafx.fxml;


    opens cmpt305.javafx_demos to javafx.fxml;
    exports cmpt305.javafx_demos;

    opens cmpt305.javafx_demos.editable_table_fxml to javafx.fxml;
    exports cmpt305.javafx_demos.editable_table_fxml;
    exports cmpt305.javafx_demos.editable_table_no_fxml;
    exports cmpt305.javafx_demos.city_selector;
}