package cmpt305.javafx_demos;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.layout.FlowPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class DrawingDemo extends Application {
    private GraphicsContext gc;
    private final Color[] colors = {Color.RED, Color.BLUE, Color.GREEN, Color.BLACK};
    int colorIdx = 0;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Drawing Demo");
        FlowPane rootNode = new FlowPane();
        rootNode.setAlignment(Pos.CENTER);

        Canvas canvas = new Canvas(400, 400);
        gc = canvas.getGraphicsContext2D();
        drawShapes(gc, colors[colorIdx]);

        Button btnChangeColor = new Button("Change Color");
        btnChangeColor.setFont(new Font("Arial", 30));
        btnChangeColor.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                drawShapes(gc, colors[++colorIdx % colors.length]);
            }
        });
        // lambda version, overwrites the previous one
        btnChangeColor.setOnAction(actionEvent -> drawShapes(gc, colors[++colorIdx % colors.length]));
        rootNode.getChildren().addAll(canvas, btnChangeColor);

        Scene scene = new Scene(rootNode, 500, 500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void drawShapes(GraphicsContext gc, Color color) {
        gc.setStroke(color);
        gc.setFill(color);
        gc.setLineWidth(2);

        gc.strokeLine(5, 5, 195, 195);
        gc.strokeOval(75, 100, 250, 200);
        gc.strokeRect(5, 200, 50, 195);
        gc.fillOval(190, 190, 20, 20);
        gc.fillRect(100, 320, 300, 40);

        double[] xPoints = {350, 300, 400};
        double[] yPoints = {0, 100, 100};
        int nPoints = 3;
        gc.fillPolygon(xPoints, yPoints, nPoints);
        gc.strokePolyline(new double[] {5, 5, 40}, new double[] {40, 5, 5}, 3);

        gc.setFont(new Font(30));
        gc.fillText("Drawing on canvas", 60, 50);
    }
}
