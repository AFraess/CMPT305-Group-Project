package cmpt305.javafx_demos.editable_table_no_fxml;

/*
 * This class defines the UI: a VBox with
 * (1) a TableView with two columns (name and age), and
 * (2) an HBox with an Add Person button.
 */

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class PersonView {

    // These fields are accessed by PersonController and PersonTableApp through getters.
    // If View and Controller were not separated, these fields could be local variables instead.
    private final TableView<Person> table = new TableView<>();
    private final TableColumn<Person, String> nameColumn = new TableColumn<>("Name");
    private final TableColumn<Person, Integer> ageColumn = new TableColumn<>("Age");
    private final Button addButton = new Button("Add Person");
    private final VBox root;

    public PersonView() {
        // Setup table
        table.setEditable(true);

        // Column width options
        // Option 1: fixed column width
/*
        nameColumn.setPrefWidth(200);
        ageColumn.setPrefWidth(100);
*/

        // Option 2: resize columns proportionally using a binding
        nameColumn.prefWidthProperty().bind(table.widthProperty().multiply(0.67));
        ageColumn.prefWidthProperty().bind(table.widthProperty().multiply(0.33));

        // Option 3: resize columns proportionally using a listener
/*
        table.widthProperty().addListener((obs, oldVal, newVal) -> {
            double tableWidth = newVal.doubleValue();
            nameColumn.setPrefWidth(tableWidth * 0.67);
            ageColumn.setPrefWidth(tableWidth * 0.33);
        });
*/

        table.getColumns().add(nameColumn);
        table.getColumns().add(ageColumn);
        // Adding the columns separately avoids the warning when adding them both together:
//        table.getColumns().addAll(nameColumn, ageColumn);
        // Alternative warning-free solution:
//        Collections.addAll(table.getColumns(), nameColumn, ageColumn);

        // Add button
        HBox buttonBox = new HBox(addButton);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setSpacing(10);

        // Layout in VBox
        root = new VBox(10, table, buttonBox);
        root.setStyle("-fx-padding: 10;");
        root.setPrefWidth(300);
        root.setPrefHeight(300);

        // Make TableView grow vertically
        VBox.setVgrow(table, Priority.ALWAYS);
    }

    public VBox getRoot() {
        return root;
    }

    public TableView<Person> getTable() {
        return table;
    }

    public TableColumn<Person, String> getNameColumn() {
        return nameColumn;
    }

    public TableColumn<Person, Integer> getAgeColumn() {
        return ageColumn;
    }

    public Button getAddButton() {
        return addButton;
    }
}
