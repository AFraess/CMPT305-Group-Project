package cmpt305.javafx_demos.editable_table_no_fxml;

/*
 * This application shows a table with Person properties name and age. Entries are editable.
 * It separates Model, View and Controller into separate classes:
 *   Model: Person class, a JavaFX Bean with Person properties name and age.
 *   View: PersonView class, defines the UI.
 *   Controller: PersonController, links the view with the data and defines the button action.
 */

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class PersonTableApp extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        PersonView view = new PersonView(); // Create the View
        new PersonController(view); // Attach the Controller to the View

        Scene scene = new Scene(view.getRoot());
        primaryStage.setScene(scene);
        primaryStage.setTitle("JavaFX MVC without FXML, Editable Table, Proportional Columns");
        primaryStage.show();
    }
}
