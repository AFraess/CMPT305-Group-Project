package cmpt305.javafx_demos.editable_table_no_fxml;

// This class follows the conventions of a JavaFX Bean:
// 1 - Use Property fields (e.g. StringProperty, IntegerProperty, etc.), typically backed by SimpleXxxProperty.
// 2 - Use JavaBean-style getters/setters, but they delegate to the property’s get() and set(...) methods.
// 3 - For each property, provide an accessor method named <name>Property() so it can be bound in JavaFX controls.
// 4 - Naming Consistency. Property names should match field names and follow JavaBean conventions.

import javafx.beans.property.StringProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class Person {
    private final StringProperty name = new SimpleStringProperty();
    private final IntegerProperty age = new SimpleIntegerProperty();

    public Person(String name, int age) {
        this.name.set(name);
        this.age.set(age);
    }

    // Name
    public String getName() {
        return name.get();
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public StringProperty nameProperty() {
        return name;
    }

    // Age
    public int getAge() {
        return age.get();
    }

    public void setAge(int age) {
        this.age.set(age);
    }

    public IntegerProperty ageProperty() {
        return age;
    }
}
