package cmpt305.javafx_demos;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BarChartAppV2 extends Application {
    private BarChart<String, Number> barChart;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Bar Chart App");

        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("Name");
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Amount ($)");
        yAxis.setLowerBound(-1000);
        yAxis.setUpperBound(1000);
        barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle("Tax Owed");
        barChart.setAnimated(false);
        barChart.setLegendVisible(true);  // default

        Button updateBtn = new Button("Update Chart");
        updateBtn.setOnAction(event -> drawChart(generateData()));

        VBox vBox = new VBox(10);
        vBox.setPadding(new Insets(10, 10, 10, 10));
        vBox.getChildren().addAll(barChart, updateBtn);

        Scene scene = new Scene(vBox, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Put data into the bar chart
    private void drawChart(List<PersonV2> data) {
        XYChart.Series<String, Number> series1 = new XYChart.Series<>();
        XYChart.Series<String, Number> series2 = new XYChart.Series<>();
        series1.setName("2025");
        series2.setName("2026");

        for (PersonV2 person : data) {
            series1.getData().add(new XYChart.Data<>(person.getFullName(), person.getTaxOwed2025()));
            series2.getData().add(new XYChart.Data<>(person.getFullName(), person.getTaxOwed2026()));
        }

        barChart.getData().clear();
        barChart.getData().add(series1);
        barChart.getData().add(series2);
    }

    // Generate random tax amount to display
    private List<PersonV2> generateData() {
        List<PersonV2> data = new ArrayList<>();
        Random rand = new Random();
        data.add(new PersonV2("Liam", "Chen", rand.nextInt(-2000, 2000), rand.nextInt(-2000, 2000)));
        data.add(new PersonV2("Sara", "Patel", rand.nextInt(-2000, 2000), rand.nextInt(-2000, 2000)));
        data.add(new PersonV2("Alex", "Nguyen", rand.nextInt(-2000, 2000), rand.nextInt(-2000, 2000)));
        data.add(new PersonV2("Nora", "Haddad", rand.nextInt(-2000, 2000), rand.nextInt(-2000, 2000)));
        data.add(new PersonV2("Owen", "Park", rand.nextInt(-2000, 2000), rand.nextInt(-2000, 2000)));

        return data;
    }
}
