package cmpt305.javafx_demos.editable_table_fxml;

/*
 * This class defines the table app controller. It
 * (1) links the columns of the TableView to Person properties,
 * (2) connects the data to the table, filling it with some initial data, and
 * (3) defines the button action.
 */

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.util.converter.IntegerStringConverter;

public class PersonController {

    @FXML
    private TableView<Person> table;
    @FXML
    private TableColumn<Person, String> nameCol;
    @FXML
    private TableColumn<Person, Integer> ageCol;

    private final ObservableList<Person> people = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Enable editing on the table
        table.setEditable(true);

        // Name column: String editor
        // short and long ways:
//        nameCol.setCellValueFactory(cellData -> cellData.getValue().nameProperty());
        nameCol.setCellValueFactory(cellData -> {
            Person person = cellData.getValue();
            return person.nameProperty();
        });
        nameCol.setCellFactory(TextFieldTableCell.forTableColumn());
        // short and long ways:
//        nameCol.setOnEditCommit(event -> event.getRowValue().setName(event.getNewValue()));
        nameCol.setOnEditCommit(event -> {
            Person person = event.getRowValue();
            person.setName(event.getNewValue());
        });

        // Age column: Integer editor
        // short and long ways:
//        ageCol.setCellValueFactory(cellData -> cellData.getValue().ageProperty().asObject());
        ageCol.setCellValueFactory(cellData -> {
            Person person = cellData.getValue();
            return person.ageProperty().asObject();
        });
        ageCol.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
        // short and long ways:
//        ageCol.setOnEditCommit(event -> event.getRowValue().setAge(event.getNewValue()));
        ageCol.setOnEditCommit(event -> {
            Person person = event.getRowValue();
            person.setAge(event.getNewValue());
        });

        // Connect ObservableList to TableView
        table.setItems(people);

        // Add initial data
        people.addAll(
                new Person("Alice Chen", 28),
                new Person("David Singh", 35),
                new Person("Fatima Ahmed", 42)
        );
    }

    @FXML
    private void handleAddPerson() {
        people.add(new Person("New Person", 20));
    }
}
