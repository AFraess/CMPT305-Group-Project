package cmpt305.javafx_demos.editable_table_fxml;

/*
 * This application shows a table with Person properties name and age. Entries are editable.
 * It separates Model, View and Controller into separate classes:
 *   Model: Person class, a JavaFX Bean with Person properties name and age.
 *   View: PersonView class, defines the UI.
 *   Controller: PersonController, links the view with the data and defines the button action.
 */

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class PersonTableApp extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("person-view.fxml"));
        Scene scene = new Scene(loader.load());
        primaryStage.setScene(scene);
        primaryStage.setTitle("JavaFX MVC with FXML, Editable Table");
        primaryStage.show();
    }
}
