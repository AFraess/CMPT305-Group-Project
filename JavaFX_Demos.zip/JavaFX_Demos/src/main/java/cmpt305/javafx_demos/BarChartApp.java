package cmpt305.javafx_demos;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BarChartApp extends Application {
    private BarChart<String, Number> barChart;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Bar Chart App");

        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("Name");
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Amount ($)");
        yAxis.setLowerBound(-1000);
        yAxis.setUpperBound(1000);
        barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle("Tax Owed");
        barChart.setAnimated(false);
        barChart.setLegendVisible(false);

        Button updateBtn = new Button("Update Chart");
        updateBtn.setOnAction(event -> drawChart(generateData()));

        VBox vBox = new VBox(10);
        vBox.setPadding(new Insets(10, 10, 10, 10));
        vBox.getChildren().addAll(barChart, updateBtn);

        Scene scene = new Scene(vBox, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Put data into the bar chart
    private void drawChart(List<Person> data) {
        XYChart.Series<String, Number> series = new XYChart.Series<>();

        for (Person person : data) {
            series.getData().add(new XYChart.Data<>(person.getFullName(), person.getTaxOwed()));
        }

        barChart.getData().clear();
        barChart.getData().add(series);
    }

    // Generate random tax amount to display
    private List<Person> generateData() {
        List<Person> data = new ArrayList<>();
        Random rand = new Random();
        data.add(new Person("Liam", "Chen", rand.nextInt(-2000, 2000)));
        data.add(new Person("Sara", "Patel", rand.nextInt(-2000, 2000)));
        data.add(new Person("Alex", "Nguyen", rand.nextInt(-2000, 2000)));
        data.add(new Person("Nora", "Haddad", rand.nextInt(-2000, 2000)));
        data.add(new Person("Owen", "Park", rand.nextInt(-2000, 2000)));

        return data;
    }
}
