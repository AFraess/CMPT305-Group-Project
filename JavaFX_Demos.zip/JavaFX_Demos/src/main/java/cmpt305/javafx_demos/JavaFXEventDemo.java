package cmpt305.javafx_demos;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

public class JavaFXEventDemo extends Application {
    private Label response;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("JavaFX Event Demo");
        FlowPane rootNode = new FlowPane(10, 10);  // Takes horizontal and vertical space between elements
        rootNode.setAlignment(Pos.CENTER);
        Button btnAlpha = new Button("Alpha");
        Button btnBeta = new Button("Beta");

        // The lengthy way, creating two anonymous classes
        btnAlpha.setOnAction(new EventHandler<ActionEvent>() { // Button.setOnAction takes a EventHandler<ActionEvent>
            @Override
            public void handle(ActionEvent event) {
                response.setText("Alpha was pressed");
            }
        });

        btnBeta.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                response.setText("Beta was pressed");
            }
        });

        // EventHandler is a functional interface; the handle() implementation can be passed as a lambda expression.
        // These overwrite the previous versions. They handle() method only runs when a button is pushed.
        btnAlpha.setOnAction(actionEvent -> response.setText("Alpha was pressed!"));
        btnBeta.setOnAction(actionEvent -> response.setText("Beta was pressed!"));

        response = new Label("Push a button");
        rootNode.getChildren().addAll(btnAlpha, btnBeta, response);

        Scene scene = new Scene(rootNode, 300, 200);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
