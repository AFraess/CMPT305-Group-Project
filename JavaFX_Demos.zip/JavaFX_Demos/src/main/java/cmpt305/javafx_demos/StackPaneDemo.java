package cmpt305.javafx_demos;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class StackPaneDemo extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // 1. Create UI components
        Button btn = new Button("Say Hello");
        btn.setOnAction(e -> System.out.println("Hello, JavaFX!"));

        // 2. Create a layout pane and add components
        StackPane rootNode = new StackPane(btn);

        double scaleFactor = 2.0;
        rootNode.setScaleX(scaleFactor);
        rootNode.setScaleY(scaleFactor);
        // 3. Create a Scene (root node + size)
        Scene scene = new Scene(rootNode, 300 * scaleFactor, 200 * scaleFactor);

        // 4. Set the scene on the stage
        primaryStage.setTitle("My First JavaFX App");
        primaryStage.setScene(scene);

        // 5. Show the stage

        primaryStage.show();
    }
}
