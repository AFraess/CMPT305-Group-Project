package cmpt305.javafx_demos;

import java.util.Objects;

// Person is a data model
public class Person {
    private final String firstName;
    private final String lastName;
    private final int taxOwed;

    public Person() {
        this("", "", 0);
    }

    public Person(String firstName, String lastName, int taxOwed) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.taxOwed = taxOwed;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getFullName() {
        return firstName + " " + lastName;
    }

    public int getTaxOwed() {
        return taxOwed;
    }

    @Override
    public String toString() {
        return "Person{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", taxOwed=" + taxOwed +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Person person = (Person) o;
        return taxOwed == person.taxOwed
                && Objects.equals(firstName, person.firstName)
                && Objects.equals(lastName, person.lastName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(firstName, lastName, taxOwed);
    }
}

