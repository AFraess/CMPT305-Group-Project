package cmpt305.javafx_demos;

import java.util.Objects;

// Person is a data model
public class PersonV2 {
    private final String firstName;
    private final String lastName;
    private final int taxOwed2025;
    private final int taxOwed2026;

    public PersonV2() {
        this("", "", 0, 0);
    }

    public PersonV2(String firstName, String lastName, int taxOwed2025, int taxOwed2026) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.taxOwed2025 = taxOwed2025;
        this.taxOwed2026 = taxOwed2026;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getFullName() {
        return firstName + " " + lastName;
    }

    public int getTaxOwed2025() {
        return taxOwed2025;
    }

    public int getTaxOwed2026() {
        return taxOwed2026;
    }

    @Override
    public String toString() {
        return "Person{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", taxOwed2025=" + taxOwed2025 + '\'' +
                ", taxOwed2026=" + taxOwed2026 +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        PersonV2 person = (PersonV2) o;
        return taxOwed2025 == person.taxOwed2025
                && taxOwed2026 == person.taxOwed2026
                && Objects.equals(firstName, person.firstName)
                && Objects.equals(lastName, person.lastName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(firstName, lastName, taxOwed2025, taxOwed2026);
    }
}

