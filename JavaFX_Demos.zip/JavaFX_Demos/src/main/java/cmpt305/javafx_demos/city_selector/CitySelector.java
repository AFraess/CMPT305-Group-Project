package cmpt305.javafx_demos.city_selector;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CitySelector extends Application {

    @Override
    public void start(Stage stage) {
        ObservableList<String> cities = FXCollections.observableArrayList(
                "Abu Dhabi", "Amsterdam", "Athens", "Bangkok", "Barcelona", "Beijing", "Berlin",
                "Bogotá", "Boston", "Brussels", "Buenos Aires", "Cairo", "Cape Town", "Chicago",
                "Delhi", "Dubai", "Dublin", "Hanoi", "Helsinki", "Hong Kong", "Houston", "Istanbul",
                "Jakarta", "Johannesburg", "Karachi", "Kiev", "Kinshasa", "Kuala Lumpur", "Lagos",
                "Lahore", "Lima", "Lisbon", "London", "Los Angeles", "Madrid", "Manila", "Melbourne",
                "Mexico City", "Miami", "Milan", "Moscow", "Mumbai", "Munich", "Nairobi", "New Delhi",
                "New York City", "Oslo", "Ottawa", "Paris", "Philadelphia", "Phoenix", "Prague",
                "Quito", "Riyadh", "Rome", "San Francisco", "Santiago", "São Paulo", "Seattle",
                "Seoul", "Shanghai", "Singapore", "Stockholm", "Sydney", "Taipei", "Tallinn",
                "Tokyo", "Toronto", "Valencia", "Vancouver", "Venice", "Vienna", "Vilnius", "Warsaw",
                "Washington D.C.", "Wellington", "Xi'an", "Yangon", "Yerevan", "Zagreb", "Zurich"
        );

        FilteredList<String> filteredCities = new FilteredList<>(cities, s -> true);

        ComboBox<String> comboBox = new ComboBox<>(filteredCities);
        comboBox.setEditable(true);

        // Flag to avoid recursive updates
        final boolean[] ignore = {false};

        // ---- 1. Filter when the user types ----
        comboBox.getEditor().textProperty().addListener((obs, oldText, newText) -> {
            if (ignore[0]) {
                return;
            }

            // Defer filtering until after JavaFX finishes updating caret/selection
            Platform.runLater(() -> {
                String filter = (newText == null) ? "" : newText.trim().toLowerCase();

                if (filter.isEmpty()) {
                    filteredCities.setPredicate(s -> true);
                } else {
                    filteredCities.setPredicate(city -> city.toLowerCase().startsWith(filter));
                }

                // Only reopen popup when user is typing text (not when selecting)
                if (!comboBox.isShowing() && !filter.isEmpty()) {
                    try {
                        comboBox.show();
                    } catch (Exception ignored) {
                        // Ignore internal selection exceptions safely
                    }
                }
            });
        });

        // ---- 2. When a city is selected, safely update the editor ----
        comboBox.valueProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal == null) {
                return;
            }

            ignore[0] = true;
            Platform.runLater(() -> {
                comboBox.getEditor().setText(newVal);
                ignore[0] = false;
            });
        });

        VBox root = new VBox(10, comboBox);
        Scene scene = new Scene(root, 250, 120);
        stage.setScene(scene);
        stage.setTitle("City Selector — Continuous Filter");
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
