package cmpt305.javafx_demos;

// Adapted from:
// https://docs.oracle.com/javase/8/javafx/user-interface-tutorial/table-view.htm (new version)
// https://docs.oracle.com/javase/8/javafx/api/javafx/scene/control/TableView.html
// Demonstrates how to format the values in a table view.
// Error checking code should be added to validate user input values.

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.text.NumberFormat;


public class TableViewApp_new extends Application {
    private TableView<Person> table;
    private ObservableList<Person> taxPayers;

    private TextField firstNameField;
    private TextField lastNameField;
    private TextField taxField;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Table View App");

        Scene scene = new Scene(createContent(), 580, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Create the application user interface
    private Parent createContent() {
        // Title
        final Label label = new Label("Tax Amount");
        label.setFont(new Font("Arial", 16));

        // Input text and table
        HBox hBox = createTextInput();
        createTable();

        // Put the UI elements into a VBox: title, input text fields, and table
        VBox vBox = new VBox(10);
        vBox.setPadding(new Insets(10, 10, 10, 10));
        vBox.getChildren().addAll(label, hBox, table);
        // Make TableView grow vertically
        VBox.setVgrow(table, Priority.ALWAYS);

        return vBox;
    }

    // Create input text fields and the Add button
    private HBox createTextInput() {
        firstNameField = new TextField();
        firstNameField.setPromptText("First name");
        lastNameField = new TextField();
        lastNameField.setPromptText("Last name");
        taxField = new TextField();
        taxField.setPromptText("Tax owed");

        Button addBtn = new Button("Add");
        // Because taxpayers is an ObservableList, and the table listens to taxpayers,
        // a change to taxpayers changes the table.
        addBtn.setOnAction(event -> {
            Person person = new Person(firstNameField.getText(), lastNameField.getText(),
                    Integer.parseInt(taxField.getText()));
            taxPayers.add(person);

            firstNameField.clear();
            lastNameField.clear();
            taxField.clear();
        });

        // Arrange the text fields and button horizontally
        HBox hBox = new HBox(10);
        hBox.getChildren().addAll(firstNameField, lastNameField, taxField, addBtn);

        return hBox;
    }

    // Create a table and configure it
    private void createTable() {
        table = new TableView<>();
        taxPayers = FXCollections.observableArrayList();  // returns an ObservableList
        table.setItems(taxPayers);  // setItems registers the table as a listener to taxPayers

        TableColumn<Person, String> firstNameCol = new TableColumn<>("First Name");
        // Specify which Person field is shown in this column.
        // A PropertyValueFactory automatically extracts a property or getter value from a table's row object.
        firstNameCol.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        // Bind the column width to the table width. This fixes the column width to 30% of the table width.
        firstNameCol.prefWidthProperty().bind(table.widthProperty().multiply(0.3));
        table.getColumns().add(firstNameCol);

        TableColumn<Person, String> lastNameCol = new TableColumn<>("Last Name");
//        lastNameCol.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        // Alternative (modern approach):
        lastNameCol.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getLastName()));
        lastNameCol.prefWidthProperty().bind(table.widthProperty().multiply(0.3));
        table.getColumns().add(lastNameCol);

        TableColumn<Person, Integer> taxCol = new TableColumn<>("Tax Owed");
        taxCol.setCellValueFactory(new PropertyValueFactory<>("taxOwed"));
        // This formats the tax amount to currency format: “For every cell in this column, create a custom TableCell.”
        // setCellFactory(...) tells JavaFX how to create the cells that appear in that column.
        // The lambda tc -> receives the column (tc) and returns a new TableCell object.
        taxCol.setCellFactory(tc -> new TableCell<>() {
            // updateItem is the key method used by TableView to refresh a cell.
            @Override
            protected void updateItem(Integer value, boolean empty) {
                // Call updateItem from javafx.scene.control.Cell
                super.updateItem(value, empty);
                // Create a currency formatter
                NumberFormat currencyFormat = NumberFormat.getCurrencyInstance();
                currencyFormat.setMaximumFractionDigits(0);
                // Set the cell text
                setText(empty ? "" : currencyFormat.format(value));
            }
        });
        taxCol.prefWidthProperty().bind(table.widthProperty().multiply(0.4));
        table.getColumns().add(taxCol);
    }
}